
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class MainSubWindow {
    private GroupSelection gs;
    private MySQL my;
    private JFrame frame;
    PrintStream out = System.out;
    
    public void setMYSQL(MySQL my) {
        this.my = my;
    }
    
    public void setGS(GroupSelection gs) {
        this.gs = gs;
    }
    
    public void launchWindow(int winNo) {
        out.println("winNo: " + winNo);
        switch(winNo) {
            case 0: // Join a new group
                join();
                break;
            case 1: // Create a new group
                create();
                break;
            case 2: // Edit Personal info
                break;
        }
    }
    
    private void join() {
        out.println("start join frame");
        frame = new JFrame();
        //frame.setMinimumSize(new Dimension(50, 100));
        frame.setBounds(100,100,200,120);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        Container container = frame.getContentPane();
        JPanel c = new JPanel();
        JLabel groupID = new JLabel("Enter Group ID: ");
        final JTextField iDEntry = new JTextField();
        //iDEntry.setSize(100, 200);
        iDEntry.setColumns(10);
        JButton join = new JButton("Join Group");
        
        join.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet.");
                out.println("triggered join final");
                if(!iDEntry.getText().equals("") ) {
                    out.println("definitely something there: " + iDEntry.getText() );
                    String collect = iDEntry.getText();
                    try {
                        /*GroupSelection.GroupAdded*/ TransferStuff ts = my.joinGroup(Runner.idNo,Integer.parseInt(collect) );
                        //System.out.println("GroupAdded: " + GroupSelection.GroupAdded);
                        if(ts != null) {
                            Runner.groupNames = ts.groupName;
                            Runner.groupIDs = ts.groupID;
                            GroupSelection.GroupChange = true;
                            gs.groupChanged();
                        }
                    } catch(Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        c.add(groupID);
        c.add(iDEntry);
        c.add(join);
        
        container.add(c);
        
        frame.setTitle("Join Group");
        frame.setVisible(true);
    }
    
    private void create() {
        frame = new JFrame();
        //frame.setMinimumSize(new Dimension(50, 100));
        frame.setBounds(100,100,200,120);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        Container container = frame.getContentPane();
        JPanel c = new JPanel();
        JLabel groupID = new JLabel("Enter Group Name: ");
        final JTextField iDEntry = new JTextField();
        //iDEntry.setSize(100, 200);
        iDEntry.setColumns(10);
        JButton join = new JButton("Create Group");
        
        join.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet.");
                out.println("triggered group final");
                if(!iDEntry.getText().equals("") ) {
                    out.println("definitely something there: " + iDEntry.getText() );
                    String collect = iDEntry.getText();
                    try {
                        /*GroupSelection.GroupAdded*/ TransferStuff ts = my.createGroup(collect);
                        //System.out.println("GroupAdded: " + GroupSelection.GroupAdded);
                        if(ts != null) {
                            Runner.groupNames = ts.groupName;
                            Runner.groupIDs = ts.groupID;
                            GroupSelection.GroupChange = true;
                            gs.groupChanged();
                        }
                    } catch(Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        
        c.add(groupID);
        c.add(iDEntry);
        c.add(join);
        
        container.add(c);
        
        frame.setTitle("Join Group");
        frame.setVisible(true);
    }
    
    private void edit() {
        
    }
}
