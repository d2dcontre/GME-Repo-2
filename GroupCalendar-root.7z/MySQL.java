import java.io.PrintStream;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MySQL {
    
    private PrintStream out = System.out;
    private Connection con;
    private ResultSet rs;
    
    public MySQL() {
        out.println("DB Start!");

        con = null;
        try {
            out.println("DB set up try");
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/newtest", "root", "root");
        } catch(Exception e) {
            e.getMessage();
        }
        /*finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }*/
    }
    
    public void close() {
        try {
            if(con != null) {
                con.close();}
            if(rs != null) {
                rs.close(); }
            out.println("closed");
        } catch (SQLException ex) {
            //Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
            ex.getMessage();
            out.println("closed error");
        }
    }
    
    public TransferStuff loginQuery(String user, String pass) {
        TransferStuff ts = null;
        String query = "select id from userdata where user = ? and pass = ?";
        String query2 ="select GroupData.GroupID,GroupData.GroupName from GroupData "
        + "join groupperson on groupperson.groupid = groupdata.groupid "
        + "join userdata on groupperson.userid = userdata.id where id = ?";
        try {
            PreparedStatement s = con.prepareStatement(query);
            s.setString(1, user);
            s.setString(2, pass);
            rs = s.executeQuery(); // Col 1: group id's; col 2: group names
            if (rs.next() ) { // get the user id
                ts = new TransferStuff();
                ts.id = rs.getInt("id");
                //Runner.idNo = id;
                System.out.println("Welcome to the Program!");
                
                s.close();
                rs.close();
                s = con.prepareStatement(query2); // Load all of the groups id is member of
                s.setString(1,"" + ts.id);
                rs = s.executeQuery();
                
                // SOURCE: http://stackoverflow.com/questions/9993972/populating-an-array-from-resultset-sql-results
                int rows = getRowCount(rs);
                System.out.println("No. Rows of Result Set: " + rows);
                if (rows > 0) {
                    ts.groupID = new int[rows];
                    ts.groupName = new String[rows];
                    rs.next();
                    for (int i = 0; i < rows; i++) {
                        ts.groupID[i] = rs.getInt("GroupID");
                        ts.groupName[i] = rs.getString("GroupName");
                        rs.next(); // necessary to move pointer
                    }
                    s.close();
                    rs.close();
                }
            } else {
                System.out.println("Incorrect username and/or password.");
            }
            //System.out.println(ts.id);
        } catch (SQLException sQLException) {
            System.out.println(sQLException.getMessage() );
        }
        return ts;
    }
    
    public String registerQuery(int userID) {
        String ret = null;
        
        String queryQ = "select name from iddata where id = ?";
        try{
            PreparedStatement query = con.prepareStatement(queryQ);
            query.setString(1, ""+userID);
            rs = query.executeQuery();
            int rowCount = getRowCount(rs);
            if(rowCount > 0) {
                rs.next();
                ret = rs.getString("name");
                
                query.close();
                rs.close();
            } /*else {
                System.out.println("No person of that ID");
            }*/
        }
        catch(Exception e){
                System.out.println("Error");
                e.printStackTrace();
                System.exit(0);
        }
        return ret;
    }
    
    // SOURCE: http://www.coderanch.com/t/303346/JDBC/databases/find-number-rows-resultset
    public static int getRowCount(ResultSet set) {
        int rowCount = 1;
        try {
            int currentRow = set.getRow();            // Get current row  
            rowCount = set.last() ? set.getRow() : 0; // Determine number of rows  
            if (currentRow == 0) // If there was no current row  
            {
                set.beforeFirst();                     // We want next() to go to first row  
            } else // If there WAS a current row  
            {
                set.absolute(currentRow);              // Restore it  
            }
        } catch (SQLException sQLException) {
            sQLException.getMessage();
            sQLException.printStackTrace();
        }
        return rowCount;
    }
    
    public int registerExecute(String id, String user, String pass, String email, String mobile,String home, String address) {
        int test = -1;
        String updateQ = "insert into UserData(id,user,pass,email,mobnum,homenum,address)"
                             + "values (?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement update = con.prepareStatement(updateQ);
            update.setString(1,id);
            update.setString(2,user);
            update.setString(3,pass);
            update.setString(4,email);
            update.setString(5,mobile);
            update.setString(6,home);
            update.setString(7,address);
            test = update.executeUpdate();
            if(test == 0)
                System.out.println("No Update Made, error");
            else
                System.out.println(test + " rows modified");
        } catch (SQLException ex) {
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return test;
    }
    
    public String[] memberQuery(int groupid) {
        String[] gMembers = null;
        String query = "select iddata.name from iddata " +
        "join groupperson on groupperson.userid = iddata.id " +
        "join groupdata on groupdata.groupid = groupperson.groupid " +
        "where groupdata.groupid = ?";
        out.println(groupid);
        try {
            out.println("Running member list query");
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1,""+groupid);
            rs = ps.executeQuery();
            int rowCount = getRowCount(rs);
            if(rowCount > 0) {
                out.println("Members found and being stored");
                gMembers = new String[rowCount];
                int i = 0;
                while(rs.next() ) {
                    gMembers[i] = rs.getString("name");
                    i++;
                }
                ps.close();
                rs.close();
            }
        } catch(Exception e) {
            e.getMessage();
            e.printStackTrace();
        }
        return gMembers;
    }
    
    public TransferStuff joinGroup(int userid, int groupid) {
        int result = -1;
        System.out.println(groupid);
        String query = "insert into GroupPerson(userid,groupid) values (?, ?)";
        String query2 ="select GroupData.GroupID,GroupData.GroupName from GroupData "
        + "join groupperson on groupperson.groupid = groupdata.groupid "
        + "join userdata on groupperson.userid = userdata.id where id = ?";
        TransferStuff ts = null;
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, ""+userid);
            ps.setString(2, ""+groupid);
            result = ps.executeUpdate();
            if(result == 0)
                out.println("No update made. Error.");
            else {
                out.println(result + " rows modified.");
                ts = new TransferStuff();
                ps = con.prepareStatement(query2); // Load all of the groups id is member of
                ps.setString(1,"" + userid);
                rs = ps.executeQuery();
                
                // SOURCE: http://stackoverflow.com/questions/9993972/populating-an-array-from-resultset-sql-results
                int rows = getRowCount(rs);
                System.out.println("No. Rows of Result Set: " + rows);
                if (rows > 0) {
                    ts.groupID = new int[rows];
                    ts.groupName = new String[rows];
                    rs.next();
                    for (int i = 0; i < rows; i++) {
                        ts.groupID[i] = rs.getInt("GroupID");
                        ts.groupName[i] = rs.getString("GroupName");
                        rs.next(); // necessary to move pointer
                    }
                    ps.close();
                    rs.close();
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return ts;
    }
    
    public TransferStuff createGroup(String name) {
        TransferStuff ts = null;
        String query = "insert into GroupData(GroupName) values (?)";
        String query2 ="select GroupData.GroupID,GroupData.GroupName from GroupData "
        + "join groupperson on groupperson.groupid = groupdata.groupid "
        + "join userdata on groupperson.userid = userdata.id where id = ?";
        try {
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            int result = ps.executeUpdate();
            if(result == 0)
                out.println("No update made. Error.");
            else {
                out.println(result + " rows modified.");
                
                String query3 = "insert into GroupPerson(UserID,GroupID) values (?,?)";
                ps = con.prepareStatement(query3);
                
                ts = new TransferStuff();
                ps = con.prepareStatement(query2); // Load all of the groups id is member of
                ps.setString(1,"" + Runner.idNo);
                rs = ps.executeQuery();
                
                // SOURCE: http://stackoverflow.com/questions/9993972/populating-an-array-from-resultset-sql-results
                int rows = getRowCount(rs);
                System.out.println("No. Rows of Result Set: " + rows);
                if (rows > 0) {
                    ts.groupID = new int[rows];
                    ts.groupName = new String[rows];
                    rs.next();
                    for (int i = 0; i < rows; i++) {
                        ts.groupID[i] = rs.getInt("GroupID");
                        ts.groupName[i] = rs.getString("GroupName");
                        rs.next(); // necessary to move pointer
                    }
                    ps.close();
                    rs.close();
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        
        return ts;
    }
    
    public String[][] calendarDSQuery(int member) {
        String[][] arr = null;
        try {
            
        } catch(Exception e) {
            
        }
        return arr;
    }
}