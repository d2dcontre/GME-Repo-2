/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class TransferStuff {
    // Used only to transfer data from a utility class like MySQL to a higher class
    public String[] groupName;
    public int[] groupID;
    public int id;
}
