public class Runner {
    
    public static int idNo;
    public static String[] groupNames;
    public static int[] groupIDs;
    
    public static void main(String args[] ) {
        System.out.println("Start!");
        MySQL my = new MySQL();
        StartGUI gui = new StartGUI(my);
    }
    
    public static void printer(String[] array) {
        System.out.println("Array Start!");
        if(array != null) {
            for(int i = 0; i < array.length; i++) {
                System.out.println(array[i]);
            }
        }
        else
            System.out.println("Name array is null.");
    }
    public static void printer(int[] array) {
        System.out.println("Array Start!");
        if (array != null) {
            for (int i = 0; i < array.length; i++) {
                System.out.println(array[i]);
            }
        } else {
            System.out.println("group ID array is null.");
        }
    }
}