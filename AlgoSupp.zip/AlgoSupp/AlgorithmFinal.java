import java.util.*;
public class AlgorithmFinal{
	/* testing stuff
	public static void main(String[] args){
		Scanner migs = new Scanner(System.in);
		String[][] magic = new String[28][101];
		for(int i=0;i<28;i++){
			String k = migs.nextLine();
			String[] temp = k.split(" ");
			for(int ii=0; ii<temp.length;ii++){
				magic[i][ii] = temp[ii];
			}
		}
		Stack<String[]> finalValues = new Stack<String[]>(); 
		finalValues = Prioritize(Sorter(Compress(magic)));
		for(int i=0; i<28;i++){
			String[] temp = finalValues.pop();
			for(int ii=0;ii<temp.length;ii++){
				System.out.print(temp[ii]+" ");		
			}
			System.out.println();
		}
	}
	*/
	
	public AlgorithmFinal(){
	}
	//String[][] values contains sched
	//The String[][] is gonna be provided by jaudric from the database(?)											
	//compression for the sorting algorithm
	//turns String[][] to ArrayList<String[]>
	public static ArrayList<String[]> Compress(String[][] values){
		ArrayList<String[]> sched = new ArrayList<String[]>();
		for(int i=0;i<28;i++){//28 time slots if interval of 30 minutes. Most likely buggy part if i counted wrong. but i doubt. this is from 7am - 9pm
			int x = values[i].length;
			String[] temp = new String[x];
			for(int ii=0;ii<x;ii++){
				temp[ii] = values[i][ii];
			}
			sched.add(temp);
		}
		return sched;
	}
	
	//Sorting
	//Uses String array with format: numberSched Member1 Member2 Member3 Member4 Member5
	//Easier for array parsing.
	//Get the String[0] element for the sched of the member. No need for splits or anything.
	//this sorts from biggest to smallest.
	public static ArrayList<String[]> Sorter(ArrayList<String[]> sched){
		int limit = sched.size();
		for(int i=0;i<28;i++){
			
		}
		for(int i=0;i<limit;i++){
			for(int ii=1;ii<limit;ii++){
				String[] compList = sched.get(ii);
				String[] currList = sched.get(ii-1);
				String[] compList2 = Shrink(compList);
				String[] currList2 = Shrink(currList);
				int k = compList2.length;
				int kk = currList2.length;
				if(k<kk){
					//System.out.println(k+ " "+kk);
					//System.out.println("sorting");
					sched.set(ii-1, compList);
					sched.set(ii,currList);
				}
			}
		}
		return sched;
	}
	//counts for the real number of elements
	public static int Counter(String[] list){
		int lim =0;
		for(int i=1;i<list.length;i++){
			if(list[i]==null){lim=i;break;}
		}
		return lim;
	}
	
	//shrinks the array to take out useless empty elements;
	public static String[] Shrink(String[] list){
		String[] newArr = new String[Counter(list)];
		for(int i=0;i<newArr.length;i++){
			//System.out.println("counting");
			newArr[i] = list[i];
		}
		return newArr;
	}	
	
	//puts values from sorted list to the stack for priority.
	//stack contains biggest values to the smallest
	public static Stack<String[]> Prioritize(ArrayList<String[]> sched){
		Stack<String[]> finalValues = new Stack<String[]>();
		for(int i=(sched.size()-1);i>=0; i--){
			finalValues.push(Shrink(sched.get(i)));
		}
		return finalValues;
	}
}