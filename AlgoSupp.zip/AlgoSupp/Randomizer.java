import java.util.*;
public class Randomizer
{
	public static void main(String ars[])
	{
		Random generator = new Random();
		for(int i = 0; i < 28; i++)
		{
			int cases = generator.nextInt(100);
			System.out.print(i);
			for(int j = 0; j <= cases; j++)
			{
				int num = generator.nextInt(256);
				System.out.print(" " +num);
			}
			System.out.println();
		}
	}
}